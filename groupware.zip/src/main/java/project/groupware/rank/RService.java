package project.groupware.rank;

import java.util.ArrayList;

public interface RService {
	
	void addRank(Rank r);
	
	ArrayList<Rank> getAll();
	
	String getRank_name(int rank_id);
	
	void editRank_name(int rank_id);
	
	void deleteRank(int rank_id);

}
