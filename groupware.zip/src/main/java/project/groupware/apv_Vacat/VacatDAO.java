package project.groupware.apv_Vacat;

public interface VacatDAO {

}
